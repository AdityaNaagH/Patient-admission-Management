"""Run with: python -m unittest test_app.py"""
import os
import sqlite3
import tempfile
import unittest
from datetime import datetime, timedelta

os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "test.db")
import app as appmod  # noqa: E402

GOOD = {
    "name": "Asha Rao", "age": 34, "gender": "Female", "ward": "ICU",
    "department": "Cardiology", "doctor": "Dr. Priya Nair",
    "admission_date": "2026-11-01", "status": "Admitted",
}


class ApiTests(unittest.TestCase):
    def setUp(self):
        appmod.init_db()
        self.c = appmod.app.test_client()
        conn = sqlite3.connect(appmod.DB_PATH)
        conn.execute("DELETE FROM patients")
        conn.commit()
        conn.close()

    def post(self, **over):
        return self.c.post("/api/patients", json={**GOOD, **over})

    def test_create_and_list(self):
        r = self.post()
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.json["name"], "Asha Rao")
        self.assertEqual(len(self.c.get("/api/patients").json), 1)

    def test_validation_errors(self):
        future = (datetime.now() + timedelta(days=3)).strftime("%Y-%m-%d")
        cases = [
            ({"name": ""}, "name"), ({"name": "Asha123"}, "name"),
            ({"name": "A$ha"}, "name"), ({"age": -1}, "age"),
            ({"age": 121}, "age"), ({"age": "abc"}, "age"),
            ({"age": 12.5}, "age"), ({"age": None}, "age"),
            ({"gender": ""}, "gender"), ({"gender": "Robot"}, "gender"),
            ({"ward": "Nope"}, "ward"), ({"department": ""}, "department"),
            ({"doctor": "Dr. Nobody"}, "doctor"),
            ({"admission_date": ""}, "admission_date"),
            ({"admission_date": "31-02-2026"}, "admission_date"),
            ({"admission_date": future}, "admission_date"),
        ]
        for over, field in cases:
            r = self.post(**over)
            self.assertEqual(r.status_code, 400, over)
            self.assertIn(field, r.json["errors"], over)
            self.assertTrue(r.json["error"])
        self.assertEqual(len(self.c.get("/api/patients").json), 0)

    def test_boundaries_ok(self):
        self.assertEqual(self.post(age=0).status_code, 201)
        self.assertEqual(self.post(age=120).status_code, 201)

    def test_missing_body(self):
        self.assertEqual(self.c.post("/api/patients").status_code, 400)

    def test_edit_discharge_delete(self):
        pid = self.post().json["id"]
        r = self.c.put(f"/api/patients/{pid}", json={**GOOD, "name": "Asha Menon"})
        self.assertEqual(r.json["name"], "Asha Menon")
        self.assertEqual(self.c.put(f"/api/patients/{pid}", json={**GOOD, "age": 500}).status_code, 400)
        self.assertEqual(self.c.patch(f"/api/patients/{pid}/discharge").json["status"], "Discharged")
        self.assertEqual(self.c.delete(f"/api/patients/{pid}").status_code, 200)
        self.assertEqual(self.c.delete(f"/api/patients/{pid}").status_code, 404)

    def test_filters_and_search(self):
        self.post(name="Ravi Kumar", ward="General Ward", department="Neurology", doctor="Dr. Anil Sharma")
        self.post(name="Ravina Das")
        get = lambda q: [p["name"] for p in self.c.get("/api/patients" + q).json]
        self.assertEqual(len(get("")), 2)
        self.assertEqual(get("?ward=General Ward"), ["Ravi Kumar"])
        self.assertEqual(get("?department=Cardiology"), ["Ravina Das"])
        self.assertEqual(get("?doctor=Dr. Anil Sharma"), ["Ravi Kumar"])
        self.assertEqual(len(get("?search=ravi")), 2)
        self.assertEqual(get("?search=kumar&ward=General Ward"), ["Ravi Kumar"])
        self.assertEqual(get("?search=%25"), [])

    def test_persistence_across_connections(self):
        self.post()
        n = sqlite3.connect(appmod.DB_PATH).execute("SELECT COUNT(*) FROM patients").fetchone()[0]
        self.assertEqual(n, 1)


if __name__ == "__main__":
    unittest.main()
