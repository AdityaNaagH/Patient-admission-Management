"""Patient Admission Management API (Flask + SQLite).

All validation lives in `validate_patient`. The frontend repeats the same
rules for fast feedback, but this is the source of truth.
"""
import os
import re
import sqlite3
from datetime import datetime, timedelta, timezone

from flask import Flask, g, jsonify, request, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE_DIR, "patients.db"))
FRONTEND_DIST = os.environ.get(
    "FRONTEND_DIST", os.path.join(BASE_DIR, "..", "frontend", "dist")
)
# "Today" for the future-date check is evaluated in IST (hospital's timezone).
IST = timezone(timedelta(hours=5, minutes=30))

GENDERS = ["Male", "Female", "Other"]
WARDS = ["General Ward", "ICU", "Pediatric Ward", "Maternity Ward", "Emergency Ward"]
DEPARTMENTS = [
    "Cardiology", "Neurology", "Orthopedics", "Pediatrics",
    "General Medicine", "Gynecology", "Emergency Medicine",
]
DOCTORS = [
    "Dr. Anil Sharma", "Dr. Priya Nair", "Dr. Rahul Verma",
    "Dr. Meera Iyer", "Dr. Suresh Reddy", "Dr. Kavita Rao",
]
STATUSES = ["Admitted", "Discharged"]

app = Flask(__name__)


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """CREATE TABLE IF NOT EXISTS patients (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            name           TEXT    NOT NULL,
            age            INTEGER NOT NULL CHECK (age BETWEEN 0 AND 120),
            gender         TEXT    NOT NULL,
            ward           TEXT    NOT NULL,
            department     TEXT    NOT NULL,
            doctor         TEXT    NOT NULL,
            admission_date TEXT    NOT NULL,
            status         TEXT    NOT NULL DEFAULT 'Admitted'
        )"""
    )
    conn.commit()
    conn.close()


# -------------------------------------------------------------- validation
def validate_patient(data):
    """Return (clean_dict, errors_dict). errors maps field -> message."""
    errors, clean = {}, {}
    if not isinstance(data, dict):
        return {}, {"_": "Request body must be a JSON object."}

    # Name: required, letters only (spaces between words allowed)
    name = data.get("name")
    if not isinstance(name, str) or not name.strip():
        errors["name"] = "Name is required."
    else:
        name = " ".join(name.split())
        if not all(word.isalpha() for word in name.split(" ")):
            errors["name"] = "Name must contain letters only (no digits or symbols)."
        elif len(name) > 100:
            errors["name"] = "Name must be 100 characters or fewer."
        else:
            clean["name"] = name

    # Age: required, whole number 0-120
    age = data.get("age")
    if isinstance(age, str) and re.fullmatch(r"\d+", age.strip() or "x"):
        age = int(age.strip())
    if age is None or age == "":
        errors["age"] = "Age is required."
    elif isinstance(age, bool) or not isinstance(age, int):
        errors["age"] = "Age must be a whole number."
    elif not 0 <= age <= 120:
        errors["age"] = "Age must be between 0 and 120."
    else:
        clean["age"] = age

    # Select fields: required and must be one of the allowed values
    for field, label, allowed in (
        ("gender", "Gender", GENDERS),
        ("ward", "Ward", WARDS),
        ("department", "Department", DEPARTMENTS),
        ("doctor", "Doctor", DOCTORS),
    ):
        value = data.get(field)
        if value in (None, ""):
            errors[field] = f"{label} is required."
        elif value not in allowed:
            errors[field] = f"{label} must be one of: {', '.join(allowed)}."
        else:
            clean[field] = value

    # Admission date: required, YYYY-MM-DD, not in the future
    date_str = data.get("admission_date")
    if not isinstance(date_str, str) or not date_str.strip():
        errors["admission_date"] = "Admission date is required."
    else:
        try:
            parsed = datetime.strptime(date_str.strip(), "%Y-%m-%d").date()
            if parsed > datetime.now(IST).date():
                errors["admission_date"] = "Admission date cannot be in the future."
            else:
                clean["admission_date"] = parsed.isoformat()
        except ValueError:
            errors["admission_date"] = "Admission date must be a valid date (YYYY-MM-DD)."

    # Status: optional (defaults to Admitted) but must be valid if given
    status = data.get("status", "Admitted")
    if status not in STATUSES:
        errors["status"] = f"Status must be one of: {', '.join(STATUSES)}."
    else:
        clean["status"] = status

    return clean, errors


def error_response(errors, status=400):
    first = next(iter(errors.values()))
    return jsonify({"error": first, "errors": errors}), status


def get_patient_or_none(patient_id):
    return get_db().execute("SELECT * FROM patients WHERE id = ?", (patient_id,)).fetchone()


# -------------------------------------------------------------------- CORS
@app.after_request
def add_cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = os.environ.get("CORS_ORIGIN", "*")
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, PATCH, DELETE, OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return resp


@app.route("/api/<path:_any>", methods=["OPTIONS"])
def preflight(_any):
    return "", 204


# ------------------------------------------------------------------ routes
@app.get("/api/health")
def health():
    return jsonify({"status": "ok"})


@app.get("/api/options")
def options():
    return jsonify(
        genders=GENDERS, wards=WARDS, departments=DEPARTMENTS,
        doctors=DOCTORS, statuses=STATUSES,
    )


@app.get("/api/patients")
def list_patients():
    clauses, params = [], []
    for field in ("ward", "department", "doctor", "status"):
        value = request.args.get(field, "").strip()
        if value:
            clauses.append(f"{field} = ?")
            params.append(value)
    search = request.args.get("search", "").strip()
    if search:
        clauses.append("name LIKE ? ESCAPE '\\'")
        escaped = search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        params.append(f"%{escaped}%")
    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    rows = get_db().execute(
        f"SELECT * FROM patients {where} ORDER BY admission_date DESC, id DESC", params
    ).fetchall()
    return jsonify([dict(r) for r in rows])


@app.post("/api/patients")
def create_patient():
    clean, errors = validate_patient(request.get_json(silent=True))
    if errors:
        return error_response(errors)
    db = get_db()
    cur = db.execute(
        """INSERT INTO patients (name, age, gender, ward, department, doctor,
                                 admission_date, status)
           VALUES (:name, :age, :gender, :ward, :department, :doctor,
                   :admission_date, :status)""",
        clean,
    )
    db.commit()
    return jsonify(dict(get_patient_or_none(cur.lastrowid))), 201


@app.put("/api/patients/<int:patient_id>")
def update_patient(patient_id):
    if get_patient_or_none(patient_id) is None:
        return error_response({"_": "Patient not found."}, 404)
    clean, errors = validate_patient(request.get_json(silent=True))
    if errors:
        return error_response(errors)
    db = get_db()
    db.execute(
        """UPDATE patients SET name=:name, age=:age, gender=:gender, ward=:ward,
               department=:department, doctor=:doctor,
               admission_date=:admission_date, status=:status
           WHERE id=:id""",
        {**clean, "id": patient_id},
    )
    db.commit()
    return jsonify(dict(get_patient_or_none(patient_id)))


@app.patch("/api/patients/<int:patient_id>/discharge")
def discharge_patient(patient_id):
    if get_patient_or_none(patient_id) is None:
        return error_response({"_": "Patient not found."}, 404)
    db = get_db()
    db.execute("UPDATE patients SET status='Discharged' WHERE id=?", (patient_id,))
    db.commit()
    return jsonify(dict(get_patient_or_none(patient_id)))


@app.delete("/api/patients/<int:patient_id>")
def delete_patient(patient_id):
    if get_patient_or_none(patient_id) is None:
        return error_response({"_": "Patient not found."}, 404)
    db = get_db()
    db.execute("DELETE FROM patients WHERE id=?", (patient_id,))
    db.commit()
    return jsonify({"message": "Patient deleted."})


# ------------------------------------- serve built React app (single deploy)
@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def frontend(path):
    if path.startswith("api/"):
        return jsonify({"error": "Not found."}), 404
    dist = os.path.abspath(FRONTEND_DIST)
    if not os.path.isdir(dist):
        return jsonify({"message": "API is running. Build the frontend to serve the UI."})
    full = os.path.join(dist, path)
    if path and os.path.isfile(full):
        return send_from_directory(dist, path)
    return send_from_directory(dist, "index.html")


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
