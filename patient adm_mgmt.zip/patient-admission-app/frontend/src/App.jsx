import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "./api.js";
import Filters from "./components/Filters.jsx";
import PatientList from "./components/PatientList.jsx";
import PatientForm from "./components/PatientForm.jsx";
import ConfirmDialog from "./components/ConfirmDialog.jsx";

const NO_FILTERS = { search: "", ward: "", department: "", doctor: "" };

export default function App() {
  const [options, setOptions] = useState(null);
  const [patients, setPatients] = useState([]);
  const [filters, setFilters] = useState(NO_FILTERS);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [formFor, setFormFor] = useState(null); // null | "new" | patient object
  const [toDelete, setToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [busyId, setBusyId] = useState(null);
  const [toast, setToast] = useState(null);
  const toastTimer = useRef();

  const notify = (text, kind = "ok") => {
    setToast({ text, kind });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 3500);
  };

  // Load dropdown options once
  useEffect(() => {
    api.options().then(setOptions).catch((e) => setLoadError(e.message));
  }, []);

  // Reload the list whenever filters change (search is debounced)
  const load = useCallback(async (f) => {
    try {
      setPatients(await api.list(f));
      setLoadError("");
    } catch (e) {
      setLoadError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => load(filters), filters.search ? 300 : 0);
    return () => clearTimeout(t);
  }, [filters, load]);

  async function handleSave(data) {
    if (formFor && formFor !== "new") {
      await api.update(formFor.id, data);
      notify("Patient updated.");
    } else {
      await api.create(data);
      notify("Patient admitted.");
    }
    setFormFor(null);
    load(filters);
  }

  async function handleDischarge(p) {
    setBusyId(p.id);
    try {
      await api.discharge(p.id);
      notify(`${p.name} discharged.`);
      load(filters);
    } catch (e) {
      notify(e.message, "error");
    } finally {
      setBusyId(null);
    }
  }

  async function confirmDelete() {
    setDeleting(true);
    try {
      await api.remove(toDelete.id);
      notify(`${toDelete.name} deleted.`);
      setToDelete(null);
      load(filters);
    } catch (e) {
      notify(e.message, "error");
    } finally {
      setDeleting(false);
    }
  }

  const filtered = Object.values(filters).some(Boolean);

  return (
    <div className="shell">
      <header className="topbar">
        <div>
          <h1>Ward Desk</h1>
          <p className="muted">Patient admissions</p>
        </div>
        <button className="btn btn-primary" disabled={!options} onClick={() => setFormFor("new")}>
          Admit patient
        </button>
      </header>

      <main>
        {options && (
          <Filters
            filters={filters}
            options={options}
            total={patients.length}
            onChange={setFilters}
            onClear={() => setFilters(NO_FILTERS)}
          />
        )}

        {loadError && (
          <p className="banner banner-error" role="alert">
            {loadError}{" "}
            <button className="link" onClick={() => load(filters)}>Retry</button>
          </p>
        )}

        {loading ? (
          <p className="empty muted">Loading patients…</p>
        ) : patients.length === 0 && !loadError ? (
          <div className="empty">
            <h2>{filtered ? "No patients match these filters" : "No patients admitted yet"}</h2>
            <p className="muted">
              {filtered
                ? "Try a different name or clear the filters."
                : "Admit the first patient to start the list."}
            </p>
            {!filtered && options && (
              <button className="btn btn-primary" onClick={() => setFormFor("new")}>
                Admit patient
              </button>
            )}
          </div>
        ) : (
          <PatientList
            patients={patients}
            busyId={busyId}
            onEdit={setFormFor}
            onDelete={setToDelete}
            onDischarge={handleDischarge}
          />
        )}
      </main>

      {formFor && options && (
        <PatientForm
          patient={formFor === "new" ? null : formFor}
          options={options}
          onSave={handleSave}
          onCancel={() => setFormFor(null)}
        />
      )}

      {toDelete && (
        <ConfirmDialog
          title="Delete this patient?"
          message={`${toDelete.name}'s record will be permanently removed. This cannot be undone.`}
          confirmLabel="Delete patient"
          busy={deleting}
          onConfirm={confirmDelete}
          onCancel={() => setToDelete(null)}
        />
      )}

      {toast && (
        <div className={`toast toast-${toast.kind}`} role="status">{toast.text}</div>
      )}
    </div>
  );
}
