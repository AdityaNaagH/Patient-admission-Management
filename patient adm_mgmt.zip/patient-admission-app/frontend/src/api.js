const BASE = (import.meta.env.VITE_API_URL || "").replace(/\/$/, "");

async function request(path, options = {}) {
  let res;
  try {
    res = await fetch(`${BASE}${path}`, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
  } catch {
    throw { message: "Cannot reach the server. Check your connection and try again." };
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    // Backend returns { error: "first message", errors: { field: message } }
    throw { message: body.error || "Something went wrong.", fields: body.errors || {} };
  }
  return body;
}

export const api = {
  options: () => request("/api/options"),
  list: (filters) => {
    const qs = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => v && qs.set(k, v));
    return request(`/api/patients?${qs}`);
  },
  create: (data) => request("/api/patients", { method: "POST", body: JSON.stringify(data) }),
  update: (id, data) =>
    request(`/api/patients/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  discharge: (id) => request(`/api/patients/${id}/discharge`, { method: "PATCH" }),
  remove: (id) => request(`/api/patients/${id}`, { method: "DELETE" }),
};
