function formatDate(iso) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("en-IN", {
    day: "numeric", month: "short", year: "numeric",
  });
}

export default function PatientList({ patients, onEdit, onDelete, onDischarge, busyId }) {
  return (
    <table className="patients">
      <thead>
        <tr>
          <th>Patient</th>
          <th>Ward</th>
          <th>Department</th>
          <th>Doctor</th>
          <th>Admitted</th>
          <th>Status</th>
          <th><span className="sr-only">Actions</span></th>
        </tr>
      </thead>
      <tbody>
        {patients.map((p) => (
          <tr key={p.id} className={p.status === "Discharged" ? "is-discharged" : ""}>
            <td data-label="Patient" className="cell-name">
              <strong>{p.name}</strong>
              <span className="muted">{p.age} yrs · {p.gender}</span>
            </td>
            <td data-label="Ward">{p.ward}</td>
            <td data-label="Department">{p.department}</td>
            <td data-label="Doctor">{p.doctor}</td>
            <td data-label="Admitted">{formatDate(p.admission_date)}</td>
            <td data-label="Status">
              <span className={`chip chip-${p.status.toLowerCase()}`}>{p.status}</span>
            </td>
            <td className="cell-actions">
              {p.status === "Admitted" && (
                <button className="btn btn-small" disabled={busyId === p.id}
                  onClick={() => onDischarge(p)}>
                  Discharge
                </button>
              )}
              <button className="btn btn-small btn-ghost" onClick={() => onEdit(p)}>Edit</button>
              <button className="btn btn-small btn-ghost btn-danger-text" onClick={() => onDelete(p)}>
                Delete
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
