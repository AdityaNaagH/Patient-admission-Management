import { useEffect, useRef, useState } from "react";
import Field from "./Field.jsx";
import { validatePatient, todayISO } from "../validation.js";

const EMPTY = {
  name: "",
  age: "",
  gender: "",
  ward: "",
  department: "",
  doctor: "",
  admission_date: todayISO(),
  status: "Admitted",
};

function Select({ id, value, onChange, options, placeholder }) {
  return (
    <select id={id} value={value} onChange={onChange}>
      <option value="">{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export default function PatientForm({ patient, options, onSave, onCancel }) {
  const [values, setValues] = useState(patient ? { ...patient } : EMPTY);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");
  const [saving, setSaving] = useState(false);
  const firstRef = useRef(null);

  useEffect(() => firstRef.current?.focus(), []);
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onCancel();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onCancel]);

  const set = (key) => (e) => setValues((v) => ({ ...v, [key]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setServerError("");
    const found = validatePatient(values);
    setErrors(found);
    if (Object.keys(found).length) return;

    setSaving(true);
    try {
      await onSave({ ...values, name: values.name.trim(), age: Number(values.age) });
    } catch (err) {
      // Show backend validation messages next to the right fields
      setErrors(err.fields || {});
      setServerError(err.message);
      setSaving(false);
    }
  }

  const editing = Boolean(patient);

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onCancel()}>
      <form className="modal" onSubmit={submit} noValidate aria-labelledby="form-title">
        <h2 id="form-title">{editing ? "Edit patient" : "Admit a patient"}</h2>

        {serverError && (
          <p className="banner banner-error" role="alert">
            {serverError}
          </p>
        )}

        <div className="grid">
          <Field label="Full name" error={errors.name} htmlFor="f-name">
            <input
              id="f-name"
              ref={firstRef}
              value={values.name}
              onChange={set("name")}
              autoComplete="off"
              placeholder="e.g. Asha Rao"
            />
          </Field>
          <Field label="Age" error={errors.age} htmlFor="f-age">
            <input
              id="f-age"
              type="number"
              inputMode="numeric"
              min="0"
              max="120"
              value={values.age}
              onChange={set("age")}
              placeholder="0–120"
            />
          </Field>
          <Field label="Gender" error={errors.gender} htmlFor="f-gender">
            <Select id="f-gender" value={values.gender} onChange={set("gender")}
              options={options.genders} placeholder="Select gender" />
          </Field>
          <Field label="Admission date" error={errors.admission_date} htmlFor="f-date">
            <input id="f-date" type="date" max={todayISO()} value={values.admission_date}
              onChange={set("admission_date")} />
          </Field>
          <Field label="Ward" error={errors.ward} htmlFor="f-ward">
            <Select id="f-ward" value={values.ward} onChange={set("ward")}
              options={options.wards} placeholder="Select ward" />
          </Field>
          <Field label="Department" error={errors.department} htmlFor="f-dept">
            <Select id="f-dept" value={values.department} onChange={set("department")}
              options={options.departments} placeholder="Select department" />
          </Field>
          <Field label="Doctor" error={errors.doctor} htmlFor="f-doctor">
            <Select id="f-doctor" value={values.doctor} onChange={set("doctor")}
              options={options.doctors} placeholder="Select doctor" />
          </Field>
          <Field label="Status" error={errors.status} htmlFor="f-status">
            <Select id="f-status" value={values.status} onChange={set("status")}
              options={options.statuses} placeholder="Select status" />
          </Field>
        </div>

        <div className="modal-actions">
          <button type="button" className="btn btn-ghost" onClick={onCancel}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? "Saving…" : editing ? "Save changes" : "Admit patient"}
          </button>
        </div>
      </form>
    </div>
  );
}
