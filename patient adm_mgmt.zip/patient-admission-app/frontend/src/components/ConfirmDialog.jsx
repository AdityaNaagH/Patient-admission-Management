import { useEffect, useRef } from "react";

export default function ConfirmDialog({ title, message, confirmLabel, busy, onConfirm, onCancel }) {
  const cancelRef = useRef(null);
  useEffect(() => cancelRef.current?.focus(), []);
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onCancel();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onCancel]);

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onCancel()}>
      <div className="modal modal-small" role="alertdialog" aria-labelledby="c-title" aria-describedby="c-msg">
        <h2 id="c-title">{title}</h2>
        <p id="c-msg" className="muted">{message}</p>
        <div className="modal-actions">
          <button ref={cancelRef} className="btn btn-ghost" onClick={onCancel}>
            Keep patient
          </button>
          <button className="btn btn-danger" onClick={onConfirm} disabled={busy}>
            {busy ? "Deleting…" : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
