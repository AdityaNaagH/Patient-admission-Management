export default function Filters({ filters, options, onChange, onClear, total }) {
  const set = (key) => (e) => onChange({ ...filters, [key]: e.target.value });
  const active = filters.ward || filters.department || filters.doctor || filters.search;

  return (
    <section className="toolbar" aria-label="Search and filters">
      <div className="search">
        <label htmlFor="search" className="sr-only">Search patients by name</label>
        <input
          id="search"
          type="search"
          placeholder="Search by patient name"
          value={filters.search}
          onChange={set("search")}
        />
      </div>
      <div className="filter-row">
        {[
          ["ward", "All wards", options.wards],
          ["department", "All departments", options.departments],
          ["doctor", "All doctors", options.doctors],
        ].map(([key, label, list]) => (
          <div key={key}>
            <label htmlFor={`flt-${key}`} className="sr-only">Filter by {key}</label>
            <select id={`flt-${key}`} value={filters[key]} onChange={set(key)}>
              <option value="">{label}</option>
              {list.map((o) => (
                <option key={o} value={o}>{o}</option>
              ))}
            </select>
          </div>
        ))}
        <button className="btn btn-ghost" onClick={onClear} disabled={!active}>
          Clear filters
        </button>
      </div>
      <p className="muted count" aria-live="polite">
        {total} {total === 1 ? "patient" : "patients"}
      </p>
    </section>
  );
}
