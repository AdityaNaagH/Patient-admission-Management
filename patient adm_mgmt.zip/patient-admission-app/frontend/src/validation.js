// Mirrors the backend rules (backend/app.py -> validate_patient).
export function todayISO() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function validatePatient(v) {
  const e = {};
  const name = (v.name || "").trim().replace(/\s+/g, " ");

  if (!name) e.name = "Name is required.";
  else if (!/^\p{L}+(?: \p{L}+)*$/u.test(name))
    e.name = "Name must contain letters only (no digits or symbols).";
  else if (name.length > 100) e.name = "Name must be 100 characters or fewer.";

  const age = String(v.age ?? "").trim();
  if (!age) e.age = "Age is required.";
  else if (!/^\d+$/.test(age)) e.age = "Age must be a whole number.";
  else if (Number(age) < 0 || Number(age) > 120) e.age = "Age must be between 0 and 120.";

  [
    ["gender", "Gender"],
    ["ward", "Ward"],
    ["department", "Department"],
    ["doctor", "Doctor"],
  ].forEach(([key, label]) => {
    if (!v[key]) e[key] = `${label} is required.`;
  });

  if (!v.admission_date) e.admission_date = "Admission date is required.";
  else if (v.admission_date > todayISO())
    e.admission_date = "Admission date cannot be in the future.";

  return e;
}
